package com.androiddevs.data.requests

data class DeleteNoteRequest(
    val id: String
)