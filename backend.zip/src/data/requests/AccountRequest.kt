package com.androiddevs.data.requests

data class AccountRequest(
    val email: String,
    val password: String
)