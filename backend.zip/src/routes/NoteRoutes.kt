package com.androiddevs.routes

import com.androiddevs.data.*
import com.androiddevs.data.collections.Note
import com.androiddevs.data.requests.DeleteNoteRequest
import io.ktor.application.call
import io.ktor.auth.UserIdPrincipal
import io.ktor.auth.authenticate
import io.ktor.auth.principal
import io.ktor.features.ContentTransformationException
import io.ktor.html.respondHtml
import io.ktor.http.*
import io.ktor.http.HttpStatusCode.Companion.BadRequest
import io.ktor.http.HttpStatusCode.Companion.Conflict
import io.ktor.http.HttpStatusCode.Companion.OK
import io.ktor.request.receive
import io.ktor.response.respond
import io.ktor.routing.Route
import io.ktor.routing.get
import io.ktor.routing.post
import io.ktor.routing.route
import kotlinx.html.*

fun Route.noteRoutes() {
    route("/notes") {
        authenticate {
            get {
                val allNotes = getAllNotes()
                call.respondHtml {
                    head {
                        styleLink("/static/css/styles.css")
                    }
                    body {
                        h1 {
                            +"All Notes"
                        }
                        for(note in allNotes) {
                            h3 {
                                +"${note.title} (Nalezy do ${note.owner}):"
                            }
                            p {
                                +note.content
                            }
                            br
                        }
                    }
                }
            }
        }
    }
    route("/getNotes") {
        authenticate {
            get {
                val email = call.principal<UserIdPrincipal>()?.name
                    ?: return@get call.respond(HttpStatusCode.Unauthorized, "Brak autoryzacji")

                val notes = getNotesForUser(email)
                call.respond(OK, notes)
            }
        }
    }

    route("/deleteNote") {
        authenticate {
            post {
                val request = try {
                    call.receive<DeleteNoteRequest>()
                } catch(e: ContentTransformationException) {
                    call.respond(BadRequest)
                    return@post
                }
                if(deleteNoteForUser(request.id)) {
                    call.respond(OK)
                } else {
                    call.respond(Conflict)
                }
            }
        }
    }
    route("/addNote") {
        authenticate {
            post {
                val note = try {
                    call.receive<Note>()
                } catch (e: ContentTransformationException) {
                    call.respond(BadRequest)
                    return@post
                }
                if(saveNote(note)) {
                    call.respond(OK)
                } else {
                    call.respond(Conflict)
                }
            }
        }
    }
}














